# -*- coding: utf-8 -*-
"""
Created on Mon Oct 23 10:28:54 2017

@author: Yves
"""


##Création de la classe Bibliothèque

class Bibliotheque(): #on crée la classe bibliothèque
 
    # Attributs
    def __init__(self, n):# Définition des attributs: on crée le nom de la bibliothèque, ainsi que les listes contenant les emprunts, les lecteurs et les livres
        self.__nom = n
        self.__liste_lecteurs = []
        self.__liste_livres = []
        self.__liste_emprunts = []
    
    # Méthodes
    def ajout_livre(self, a, t, num, nb):
        '''ajout d'une instance de la classe Livre (en cas d'achat d'un nouveau livre)'''
        self.__liste_livres.append(Livre(a, t, num, nb))
        
    def get_livre_num(self, num): 
        '''retrouver un livre avec son numéro'''
        for l in self.__liste_livres:
            if l.get_num() == num:
                return l
            
    def get_livre_titre(self, t): 
        '''retrouver un livre à partir de son titre'''
        for l in self.__liste_livres:
            if l.get_titre() == t:
                return l
        
    
    def affiche_livres(self): 
        '''afficher la liste des livres'''
        for x in self.__liste_livres:
            print(x)
    
    def ajout_exemplaire(self, l): 
        '''ajoute un exemplaire d'un Livre donné'''
        l.set_nb_achetes(1)
        l.set_nb_dispos(1)
        
    def ajout_lecteur(self, n, p, ad, num): 
        '''ajout d'une instance de la classe Lecteur'''
        self.__liste_lecteurs.append(Lecteur(n, p, ad, num))
        
    def get_lecteur_num(self, num): 
        '''retrouver un lecteur à partir de son numéro'''
        
        for l in self.__liste_lecteurs:
            if l.get_num() == num:
                return l
    
    def get_lecteur_nom(self, nom, prenom):
        '''retrouver un lecteur à partir de son nom et de son prénom'''
        for l in self.__liste_lecteurs:
            if (l.get_nom() == nom) and (l.get_prenom() == prenom):
                return l
        
    
    def affiche_lecteurs(self): 
        '''affiche la liste des lecteurs'''
        for x in self.__liste_lecteurs:
            print(x)
            
            
    def existe_livre_num(self, num): 
        '''renvoie un booléen suivant si le livre existe dans la liste des livre'''
        for l in self.__liste_livres:
            if l.get_num() == num:
                return True
        return False
    
    def ajout_emprunt(self, num_lect, num_livre):
        '''permet de réaliser un emprunt si l'emprunt est possible'''
        if self.existe_livre_num(num_livre):
            livre = self.get_livre_num(num_livre)
            lect = self.get_lecteur_num(num_lect)
            if livre.get_nb_dispos() >= 1:
                self.__liste_emprunts.append(Emprunt(num_lect, num_livre))
                lect.set_nb_emprunts(1)
                livre.set_nb_dispos(-1)
        
    def affiche_emprunts(self): 
        '''affiche la liste des emprunts'''
        for x in self.__liste_emprunts:
            print(x)
        
    def retirer_livre(self, num):
        '''retire un livre de la bibliothèque'''
        for x in self.__liste_livres:
            if x.get_num() == num:
                self.__liste_livres.remove(x)
    
    def retirer_lecteur(self, num):
        '''désinscrit un lecteur de la bibliothèque'''
        for x in self.__liste_lecteurs:
            if x.get_num() == num:
                self.__liste_lecteurs.remove(x)
                
    def retour_emprunt(self, num_lect, num_livre):
        '''retire un emprunt de la liste des emprunts au retour du livre'''
        
        for x in self.__liste_emprunts:
            if (x.get_lecteur() == num_lect) and (x.get_livre() == num_livre):
                self.__liste_emprunts.remove(x)
        
        
## Création de la classe Lecteur   
class Lecteur():
    
    #Attributs 
    def __init__(self, n, p, ad, num):
        self.__nom = n
        self.__prenom = p
        self.__adresse = ad
        self.__numero = num
        self.__nb_emprunts = 0
     
    #Méthodes    
    def get_nom(self):
        '''retourne le nom d'un lecteur'''
        return self.__nom
    
    def get_prenom(self):
        '''retourne le prénom d'un lecteur'''
        return self.__prenom
    
    def get_adresse(self):
        '''retourne l'adresse d'un lecteur'''
        return self.__adresse
    
    def set_adresse(self, a):
        '''change l'adresse d'un lecteur'''
        self.__adresse = a
    
    def get_num(self):
        '''retourne le numéro du lecteur'''
        return self.__numero
    
    def get_nb_emprunts(self):
        ''' retourne le nombre de livres qu'un lecteur a emprunté'''
        return self.__nb_emprunts
    
    def set_nb_emprunts(self, n):
        ''' change le nombre de livres emprunté par un lecteur'''
        self.__nb_emprunts += n
    
    def __str__(self):
        '''définit ce qui est affiché lorsqu'on affiche une instance de la classe lecteur'''
        return 'Nom :'+ self.__nom + ', Prénom :'+ self.__prenom + ', Adresse :'+ self.__adresse
        
    
        
## Création de la classe Livre       
class Livre():
    
    #Attributs
    def __init__(self, a, t, num, nb):
        
        self.__nom_auteur = a
        self.__titre_ouvrage = t
        self.__num_livre = num
        self.__nb_achetes = nb
        self.__nb_dispos = nb
        
    #Méthodes     
    def get_auteur(self):
        '''retourne l'auteur du livre'''
        return self.__nom_auteur
    
    def get_titre(self):
        '''retourne le titre du livre'''
        return self.__titre_ouvrage
    
    def get_num(self):
        '''retourne le numéro du livre'''
        return self.__num_livre
    
    def get_nb_achetes(self):
        '''retourne le nombre de livres achetés par la bibliothèque'''
        return self.__nb_achetes
    
    def set_nb_achetes(self, n):
        '''change le nombre de livres achetés(achat d'un livre)'''
        self.__nb_achetes += n
    
    def get_nb_dispos(self):
        '''retourne le nombre de livres disponibles (non empruntés)'''
        return self.__nb_dispos
    
    def set_nb_dispos(self, n):
        '''change le nombre de livres disponibles'''
        self.__nb_dispos += n
    
    def __str__(self):
        '''définit ce qui est affiché lorsqu'on affiche une instance de la classe livre'''
        return 'Auteur :'+self.__nom_auteur+', Titre :'+self.__titre_ouvrage+', Numéro :'+str(self.__num_livre)+', Nombre achetés :'+str(self.__nb_achetes)+', Nombre dispos :'+str(self.__nb_dispos)
        
 ## Création de la classe Emprunt   
class Emprunt():
    
    #Attributs
    def __init__(self, idlect, idlivre):
        self.__id_lecteur = idlect
        self.__id_livre = idlivre
    
    #Méthodes 
    def get_lecteur(self):
        '''retourne le numéro du lecteur qui a emprunté un livre''' 
        return self.__id_lecteur
    
    def get_livre(self):
        '''retourne le numéro du livre qui a été emprunté'''
        return self.__id_livre
    
    
    def __str__(self):
        '''définit ce qui est affiché lorsqu'on affiche une instance de la classe Emprunt'''
        return 'Emprunteur :'+str(self.__id_lecteur)+', Livre :'+str(self.__id_livre)
        


    