# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 09:32:30 2017

@author: Yves
"""

from bibliotheque import *
# Creation d'une bibliotheque
b = Bibliotheque('Bibliotheque ECL')
# Ajout de lecteurs
b.ajout_lecteur('Duval','Pierre','rue de la Paix',1)
b.ajout_lecteur('Dupond','Laurent','rue de la Gare',2)
b.ajout_lecteur('Martin','Marie','rue La Fayette',3)
b.ajout_lecteur('Dubois','Sophie','rue du Stade',4)

# Ajout de livres
b.ajout_livre('Honore de Balzac','Le Pere Goriot',101,2)
b.ajout_livre('Emilie Bronte','Les Hauts de Hurlevent',102,2)
b.ajout_livre('Antoine de Saint Exupery','L\'Etranger',104,2)

## Affichage des lecteurs et des livres
print('\n---Liste des lecteurs :')
print('-------------------------------')
b.affiche_lecteurs()
#print('\n---Liste des livres :')
#print('-------------------------------')
#b.affiche_livres()
## Recherches de lecteurs par numero
#print('\n---Recherche de lecteurs :')
#print('-------------------------------')
#
#lect = b.get_lecteur_num(1)
#if lect != None:
#    print(lect)
#else:
#    print('Lecteur non trouve')
#    
#lect = b.get_lecteur_num(6)
#
#if lect != None:
#    print(lect)
#else:
#    print('Lecteur non trouve')
#
## Recherches de lecteurs par nom
#lect = b.get_lecteur_nom('Martin','Marie')
#
#if lect != None:
#    print(lect)
#else:
#    print('Lecteur non trouve')
#
#lect = b.get_lecteur_nom('Le Grand','Paul')
#
#if lect != None:
#    print(lect)
#else:
#    print('Lecteur non trouve')
#    
## Recherches de livres par numero
#print('\n---Recherche de livres :')
#print('-------------------------------')
#livre = b.get_livre_num(101)
#
#if livre != None:
#    print('Livre trouve :',livre)
#else:
#    print('Livre non trouve')
#
#livre = b.get_livre_num(106)
#if livre != None:
#    print('Livre trouve :',livre)
#    
#else:
#    print('Livre non trouve')
#
## Recherches de livres par titre
#livre = b.get_livre_titre('Les Hauts de Hurlevent')
#if livre != None:
#    print('Livre trouve :',livre)
#else:
#    print('Livre non trouve')
#livre = b.get_livre_titre('Madame Bovarie')
#if livre != None:
#    print('Livre trouve :',livre)
#else:
#    print('Livre non trouve')
    
# Quelques emprunts
print('\n---Quelques emprunts :')
print('-------------------------------')
b.ajout_emprunt(1,101)
b.ajout_emprunt(1,104)
b.ajout_emprunt(2,101)
b.ajout_emprunt(2,105)
b.ajout_emprunt(3,101)
b.ajout_emprunt(3,104)
b.ajout_emprunt(4,102)
b.ajout_emprunt(4,103)
#Affichage des emprunts, des lecteurs et des livres
print('\n---Liste des emprunts :')
print('-------------------------------')

b.affiche_emprunts()
#print('\n---Liste des lecteurs :')
#print('-------------------------------')
#b.affiche_lecteurs()
#print('\n---Liste des livres :')
#print('-------------------------------')
#b.affiche_livres()

#Quelques retours de livres
print('\n---Quelques retours de livres :')
print('-------------------------------')
b.retour_emprunt(1,101)
b.retour_emprunt(1,102)
b.retour_emprunt(3,104)
b.retour_emprunt(10,108)
#Affichage des emprunts, des lecteurs et des livres
print('\n---Liste des emprunts :')
print('-------------------------------')
b.affiche_emprunts()
#print('\n---Liste des lecteurs :')
#print('-------------------------------')
#b.affiche_lecteurs()
#print('\n---Liste des livres :')
#print('-------------------------------')
#b.affiche_livres()
#
# Suppression de quelques livres

rep = b.retirer_livre(101)
print('\n---Liste des livres :')
print('-------------------------------')
b.affiche_livres()

#if not rep:
#    print('Retrait du livre impossible')
#else:
#    print('Retrait du livre effectue')
##b.retour_livre(2,101)
#rep = b.retrait_livre(101)
#
#if not rep:
#    print('Retrait du livre impossible')
#else:
#    print('Retrait du livre effectue')
## Suppression de quelques lecteurs
#rep = b.retirer_lecteur(1)
#if not rep:
#    print('Retrait du lecteur impossible')
#else:
#    print('Retrait du lecteur effectue')
#b.retour_livre(1,104)
#rep = b.retrait_lecteur(1)
#if not rep:
#    print('Retrait du lecteur impossible')
#else:
#    print('Retrait du lecteur effectue')
## Affichage des emprunts, des lecteurs et des livres
#print('\n---Liste des emprunts :')
#print('-------------------------------')
#b.affiche_emprunts()
#print('\n---Liste des lecteurs :')
#print('-------------------------------')
#b.affiche_lecteurs()
print('\n---Liste des livres :')
print('-------------------------------')
b.affiche_livres()