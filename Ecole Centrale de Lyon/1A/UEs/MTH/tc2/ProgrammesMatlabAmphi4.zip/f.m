function du = f(t,u)
du = 2*t*u;
